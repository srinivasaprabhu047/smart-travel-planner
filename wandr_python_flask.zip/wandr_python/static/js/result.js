/* ============================================================
   WANDR — result.js  (Flask edition)
   ============================================================ */
'use strict';
const PIE_COLORS = ['#C4622D','#D4A843','#6B8F71','#4A7FA5','#8B5CF6','#E8541A'];

document.addEventListener('DOMContentLoaded', () => {
  const raw = sessionStorage.getItem('wandr_trip');
  if (!raw) { window.location.href = '/planner'; return; }
  try {
    const { plan, state } = JSON.parse(raw);
    window._plan = plan; window._state = state;
    renderAll(plan, state);
  } catch (e) { window.location.href = '/planner'; }
});

function renderAll(plan, state) {
  renderHero(plan, state);
  renderMeta(plan, state);
  renderDays(plan);
  renderTips(plan);
  renderBudget(plan, state);
  renderPie(plan.budget);
  renderHotels(plan);
}

function renderHero(plan, state) {
  const t = document.getElementById('result-title');
  const s = document.getElementById('result-sub');
  if (t) t.textContent = (state.duration || 5) + ' Days in ' + (state.dest || '') + ' ' + (state.destEmoji || '✈️');
  if (s) s.textContent = 'Curated for ' + state.style + ' · ' + state.travellers + ' · ' + (state.interests || []).slice(0,3).join(' & ');
}

function renderMeta(plan, state) {
  const el = document.getElementById('meta-bar');
  if (!el) return;
  const total = Object.values(plan.budget || {}).reduce((a,b) => a+b, 0);
  const chips = [
    {l:'Duration',   v: state.duration + ' Nights'},
    {l:'Travellers', v: state.travellers},
    {l:'Budget',     v: '₹' + (state.budget||0).toLocaleString('en-IN')},
    {l:'Est. Cost',  v: '₹' + total.toLocaleString('en-IN')},
    {l:'Per Day',    v: '₹' + Math.round(total / (state.duration||5)).toLocaleString('en-IN')},
    {l:'Style',      v: state.style}
  ];
  el.innerHTML = chips.map(c => `<div class="meta-chip"><div class="meta-lbl">${c.l}</div><div class="meta-val">${c.v}</div></div>`).join('');
}

function renderDays(plan) {
  const dc = document.getElementById('days-container');
  if (!dc) return;
  dc.innerHTML = (plan.days || []).map(day => `
    <div class="day-block">
      <div class="day-hdr">
        <div><div class="day-lbl">Day ${day.day}</div><div class="day-name">${esc(day.theme||'')}</div></div>
        <div class="day-cost-lbl">Est. <strong>₹${Number(day.dayCost||0).toLocaleString('en-IN')}</strong></div>
      </div>
      <div class="day-acts">${(day.activities||[]).map(a => `
        <div class="act">
          <div class="act-time">${esc(a.time||'')}</div>
          <div class="act-ico">${a.icon||'📍'}</div>
          <div class="act-info"><div class="act-name">${esc(a.name||'')}</div><div class="act-desc">${esc(a.description||'')}</div></div>
          <div class="act-cost">${Number(a.cost)>0?'₹'+Number(a.cost).toLocaleString('en-IN'):'Free'}</div>
        </div>`).join('')}
      </div>
    </div>`).join('');
}

function renderTips(plan) {
  const dc = document.getElementById('days-container');
  if (!dc || !plan.tips?.length) return;
  dc.insertAdjacentHTML('beforeend',
    '<div class="sec-title" style="margin-top:40px">Travel Tips</div>' +
    plan.tips.map(t => `<div class="tip-block">💡 ${esc(t)}</div>`).join('')
  );
}

function renderBudget(plan, state) {
  const le = document.getElementById('exp-list');
  const te = document.getElementById('total-cost');
  const re = document.getElementById('remaining');
  if (!le) return;
  const cats = Object.entries(plan.budget || {});
  const total = cats.reduce((s,[,v]) => s+Number(v), 0);
  le.innerHTML = cats.map(([k,v],i) => `
    <div class="exp-item">
      <div class="exp-cat"><div class="exp-dot" style="background:${PIE_COLORS[i%6]}"></div><div class="exp-name">${cap(k)}</div></div>
      <div class="exp-amt">₹${Number(v).toLocaleString('en-IN')}</div>
    </div>`).join('');
  if (te) te.textContent = '₹' + total.toLocaleString('en-IN');
  if (re) {
    const rem = (state.budget||0) - total;
    re.textContent = rem >= 0 ? '✓ ₹'+rem.toLocaleString('en-IN')+' within budget' : '⚠ ₹'+Math.abs(rem).toLocaleString('en-IN')+' over budget';
    re.className = 'remaining' + (rem < 0 ? ' over' : '');
  }
}

function renderPie(budget) {
  const svg = document.getElementById('pie-svg');
  if (!svg || !budget) return;
  const slices = Object.values(budget).map((v,i) => ({value:Number(v),color:PIE_COLORS[i%6]}));
  const total = slices.reduce((s,x) => s+x.value, 0);
  if (!total) return;
  let angle = -Math.PI/2, paths = '';
  slices.forEach(s => {
    const sweep = (s.value/total)*Math.PI*2 - 0.025;
    if (sweep <= 0) return;
    const x1=80+68*Math.cos(angle), y1=80+68*Math.sin(angle);
    const x2=80+68*Math.cos(angle+sweep), y2=80+68*Math.sin(angle+sweep);
    paths += `<path d="M80,80 L${x1},${y1} A68,68 0 ${sweep>Math.PI?1:0},1 ${x2},${y2} Z" fill="${s.color}" opacity=".87"/>`;
    angle += sweep + 0.025;
  });
  svg.innerHTML = paths + '<circle cx="80" cy="80" r="26" fill="var(--sand)"/>';
}

function renderHotels(plan) {
  const el = document.getElementById('hotel-list');
  if (!el || !plan.hotels) return;
  el.innerHTML = plan.hotels.map(h => `
    <div class="hotel-row">
      <div><div class="hotel-name">${esc(h.name||'')}</div><div class="hotel-stars">${'★'.repeat(Math.min(parseInt(h.stars)||3,5))}</div></div>
      <div class="hotel-price">₹${Number(h.pricePerNight||0).toLocaleString('en-IN')}/night</div>
    </div>`).join('');
}

function downloadPlan() {
  const plan = window._plan, state = window._state;
  if (!plan || !state) return;
  const total = Object.values(plan.budget||{}).reduce((a,b)=>a+Number(b),0);
  let txt = `\n${'═'.repeat(50)}\n  WANDR — SMART TRAVEL PLANNER (Python Edition)\n${'═'.repeat(50)}\n\n`;
  txt += `  ${state.duration} Days in ${state.dest}\n`;
  txt += `  Style: ${state.style}  |  Travellers: ${state.travellers}\n`;
  txt += `  Budget: Rs.${(state.budget||0).toLocaleString('en-IN')}\n\n`;
  if (plan.summary) txt += `  ${plan.summary}\n\n`;
  txt += `DAY-WISE ITINERARY\n${'─'.repeat(40)}\n`;
  (plan.days||[]).forEach(d => {
    txt += `\n  ▸ Day ${d.day}: ${d.theme}\n`;
    (d.activities||[]).forEach(a => txt += `    ${(a.time||'').padEnd(6)} ${a.icon||''} ${(a.name||'').padEnd(35)} ${Number(a.cost)>0?'Rs.'+Number(a.cost).toLocaleString('en-IN'):'Free'}\n`);
    txt += `    Day Total: Rs.${Number(d.dayCost||0).toLocaleString('en-IN')}\n`;
  });
  txt += `\nBUDGET BREAKDOWN\n${'─'.repeat(40)}\n`;
  Object.entries(plan.budget||{}).forEach(([k,v]) => txt += `  ${cap(k).padEnd(22)} Rs.${Number(v).toLocaleString('en-IN')}\n`);
  txt += `  ${'─'.repeat(34)}\n  ${'Total'.padEnd(22)} Rs.${total.toLocaleString('en-IN')}\n`;
  if (plan.tips?.length) { txt += `\nTRAVEL TIPS\n${'─'.repeat(40)}\n`; plan.tips.forEach((t,i)=>txt+=`  ${i+1}. ${t}\n`); }
  txt += `\n${'═'.repeat(50)}\n  Generated by Wandr — Flask + SQLite + Claude AI\n${'═'.repeat(50)}\n`;
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([txt],{type:'text/plain'}));
  a.download = 'Wandr_' + (state.dest||'Trip').replace(/\s+/g,'_') + '_' + (state.duration||5) + 'Days.txt';
  a.click(); URL.revokeObjectURL(a.href);
}

const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
