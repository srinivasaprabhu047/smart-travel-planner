/* ============================================================
   WANDR — destinations.js  (Flask edition)
   Fetches destination data from /api/destinations
   ============================================================ */
'use strict';
let activeRegion = 'All';

document.addEventListener('DOMContentLoaded', async () => {
  await loadDestinations('All');
  await loadFilters();
});

async function loadFilters() {
  const res = await fetch('/api/destinations');
  const dests = await res.json();
  const regions = ['All', ...new Set(dests.map(d => d.region).filter(Boolean))];
  const fb = document.getElementById('filter-bar');
  if (!fb) return;
  fb.innerHTML = regions.map(r =>
    `<button class="filter-btn${r==='All'?' active':''}" onclick="filterByRegion('${r}',this)">${r}</button>`
  ).join('');
}

async function filterByRegion(region, btn) {
  activeRegion = region;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  await loadDestinations(region);
}

async function loadDestinations(region) {
  const grid = document.getElementById('dest-grid');
  if (!grid) return;
  grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:rgba(26,22,18,0.4);font-family:\'DM Mono\',monospace;font-size:.8rem">Loading destinations…</div>';
  try {
    const url = region && region !== 'All' ? `/api/destinations?region=${encodeURIComponent(region)}` : '/api/destinations';
    const res = await fetch(url);
    const dests = await res.json();
    renderDestinations(grid, dests);
  } catch (e) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--rust)">Failed to load destinations. Please refresh.</div>';
  }
}

const BG_COLORS = ['rgba(196,98,45,0.08)','rgba(74,127,165,0.08)','rgba(107,143,113,0.08)','rgba(212,168,67,0.08)','rgba(139,92,246,0.08)'];

function renderDestinations(grid, dests) {
  if (!dests.length) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:rgba(26,22,18,0.4)">No destinations found for this region.</div>';
    return;
  }
  grid.innerHTML = dests.map((d, i) => {
    const tags = Array.isArray(d.tags) ? d.tags : JSON.parse(d.tags || '[]');
    return `
      <a href="/planner?dest=${encodeURIComponent(d.name)}&country=${encodeURIComponent(d.country||'')}&emoji=${encodeURIComponent(d.emoji||'✈️')}" class="dest-full-card">
        <div class="dest-card-top" style="background:${BG_COLORS[i%5]}">${d.emoji||'🌍'}</div>
        <div class="dest-card-body">
          <h3>${d.name}</h3>
          <div class="dest-country-lbl">${d.country||''} · ${d.region||''}</div>
          <p class="dest-desc">${d.description||''}</p>
          <div class="dest-tags">${tags.map(t=>`<span class="dest-card-tag">${t}</span>`).join('')}</div>
        </div>
        <div class="dest-card-footer">
          <div class="dest-budget">From <strong>₹${(d.budget_min||0).toLocaleString('en-IN')}</strong></div>
          <div class="dest-link">Plan Trip →</div>
        </div>
      </a>`;
  }).join('');
}
