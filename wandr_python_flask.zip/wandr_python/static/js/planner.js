/* ============================================================
   WANDR — planner.js  (Flask edition)
   All AI calls and budget splits go through the Python backend
   ============================================================ */
'use strict';

const state = {
  dest:'', destEmoji:'', destCountry:'',
  duration:5, travellers:'2 people',
  style:'Comfort Traveller', interests:['Culture','Nature'],
  budget:80000, hotelPref:'Mid-range Hotel', specialReq:''
};

// ── STEPS ──────────────────────────────────────────────────
let currentStep = 0;

function goStep(n) {
  if (n > 0 && !state.dest) { showToast('Please select a destination first.'); return; }
  document.getElementById('step' + currentStep).classList.remove('active');
  document.getElementById('ps' + currentStep).classList.remove('active');
  document.getElementById('ps' + currentStep).classList.add('done');
  currentStep = n;
  document.getElementById('step' + n).classList.add('active');
  document.getElementById('ps' + n).classList.add('active');
  document.getElementById('ps' + n).classList.remove('done');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── DESTINATION ────────────────────────────────────────────
function selectDest(el, name, country, emoji) {
  document.querySelectorAll('.dest-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  state.dest = name; state.destCountry = country; state.destEmoji = emoji;
  const ci = document.getElementById('custom-dest');
  if (ci) ci.value = '';
  updateSummary();
}

function updateCustomDest(val) {
  if (val && val.trim()) {
    document.querySelectorAll('.dest-card').forEach(c => c.classList.remove('selected'));
    state.dest = val.trim(); state.destEmoji = '✈️'; state.destCountry = '';
    updateSummary();
  }
}

function toggleInterest(el) {
  el.classList.toggle('selected');
  state.interests = Array.from(document.querySelectorAll('.itag.selected'))
    .map(t => t.textContent.trim().replace(/^\S+\s+/, '').trim());
  updateSummary();
}

// ── RANGE INPUTS ───────────────────────────────────────────
function updateDuration(v) {
  state.duration = parseInt(v);
  const el = document.getElementById('duration-val');
  if (el) el.textContent = v + ' night' + (parseInt(v) > 1 ? 's' : '');
  fetchBudgetSplit();
  updateSummary();
}

function updateBudget(v) {
  state.budget = parseInt(v);
  const ve = document.getElementById('budget-val');
  const xe = document.getElementById('budget-exact');
  if (ve) ve.textContent = '₹' + parseInt(v).toLocaleString('en-IN');
  if (xe) xe.value = v;
  fetchBudgetSplit();
  updateSummary();
}

function syncBudget(v) {
  const val = Math.min(Math.max(parseInt(v) || 10000, 10000), 500000);
  state.budget = val;
  const re = document.getElementById('budget-range');
  const ve = document.getElementById('budget-val');
  if (re) re.value = val;
  if (ve) ve.textContent = '₹' + val.toLocaleString('en-IN');
  fetchBudgetSplit();
  updateSummary();
}

// ── BUDGET SPLIT (from Flask API) ──────────────────────────
let budgetSplitTimer = null;
async function fetchBudgetSplit() {
  clearTimeout(budgetSplitTimer);
  budgetSplitTimer = setTimeout(async () => {
    try {
      const res = await fetch('/api/budget-split', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ budget: state.budget, style: state.style, duration: state.duration })
      });
      const data = await res.json();
      const pdEl = document.getElementById('sum-perday');
      if (pdEl) pdEl.textContent = '≈ ₹' + (data.per_day || 0).toLocaleString('en-IN') + ' / day';
    } catch (_) {}
  }, 400);
}

// ── SUMMARY SIDEBAR ────────────────────────────────────────
function setEl(id, val, empty) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = val;
  el.className = 'sum-val' + (empty ? ' empty' : '');
}

function updateSummary() {
  setEl('sum-dest', state.dest || 'Not selected', !state.dest);
  setEl('sum-dur', state.duration + ' nights', false);
  const tv = document.getElementById('travellers');
  if (tv) { state.travellers = tv.options[tv.selectedIndex].text; setEl('sum-trav', state.travellers, false); }
  const sy = document.getElementById('travel-style');
  if (sy) { state.style = sy.options[sy.selectedIndex].value; setEl('sum-style', state.style, false); }
  const hp = document.getElementById('hotel-pref');
  if (hp) { state.hotelPref = hp.options[hp.selectedIndex].value; setEl('sum-hotel', state.hotelPref, false); }
  setEl('sum-interests', state.interests.length ? state.interests.join(', ') : 'None selected', !state.interests.length);
  setEl('sum-budget', '₹' + state.budget.toLocaleString('en-IN'), false);
  const perDay = Math.round(state.budget / state.duration);
  setEl('sum-perday', '≈ ₹' + perDay.toLocaleString('en-IN') + ' / day', false);
  const bf = document.getElementById('bfill');
  if (bf) bf.style.width = Math.min((state.budget / 500000) * 100, 100) + '%';
}

// ── GENERATE PLAN (calls Flask /api/generate) ───────────────
async function generatePlan() {
  const sr = document.getElementById('special-req');
  state.specialReq = sr ? sr.value : '';

  showLoading();

  try {
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dest: state.dest,
        destCountry: state.destCountry,
        duration: state.duration,
        travellers: state.travellers,
        style: state.style,
        interests: state.interests,
        budget: state.budget,
        hotelPref: state.hotelPref,
        specialReq: state.specialReq
      })
    });

    const data = await res.json();
    hideLoading();

    if (data.success) {
      sessionStorage.setItem('wandr_trip', JSON.stringify({ plan: data.plan, state: { ...state }, itinerary_id: data.itinerary_id }));
      window.location.href = '/result';
    } else {
      // API failed — use fallback
      const plan = makeFallback();
      sessionStorage.setItem('wandr_trip', JSON.stringify({ plan, state: { ...state }, fallback: true }));
      window.location.href = '/result';
    }
  } catch (e) {
    hideLoading();
    const plan = makeFallback();
    sessionStorage.setItem('wandr_trip', JSON.stringify({ plan, state: { ...state }, fallback: true }));
    window.location.href = '/result';
  }
}

// ── FALLBACK PLAN ──────────────────────────────────────────
function makeFallback() {
  const d = state.dest || 'the destination';
  const bpd = Math.floor(state.budget / state.duration);
  const acts = [
    { time:'08:00', icon:'☕', name:'Breakfast at local café',       description:'Start the day with authentic local flavours at a neighbourhood favourite.',                  cost: Math.round(bpd*.05) },
    { time:'10:00', icon:'🏛️', name:'Heritage site visit',           description:'Explore the most iconic historical landmark in ' + d + '.',                                  cost: Math.round(bpd*.10) },
    { time:'13:00', icon:'🍜', name:'Local cuisine lunch',            description:'Savour regional specialties at a well-rated restaurant.',                                    cost: Math.round(bpd*.08) },
    { time:'15:30', icon:'🎨', name:'Museum or gallery',              description:'Immerse yourself in the local art and cultural scene.',                                       cost: Math.round(bpd*.10) },
    { time:'18:30', icon:'🌅', name:'Sunset viewpoint',               description:'Catch the golden hour at the most iconic viewpoint.',                                         cost: 0 },
    { time:'20:00', icon:'🍷', name:'Dinner at scenic restaurant',    description:'End the day with a memorable meal and beautiful views.',                                      cost: Math.round(bpd*.12) },
  ];
  const themes = ['Arrival & Discovery','Historic Highlights','Culture & Cuisine','Nature & Relaxation','Markets & Farewell'];
  const days = Array.from({ length: state.duration }, (_, i) => ({ day: i+1, theme: themes[i%5], activities: acts, dayCost: bpd }));
  const b = state.budget;
  return {
    summary: `A carefully crafted ${state.duration}-day journey through ${d}, designed for ${state.style.toLowerCase()} travellers.`,
    days, tips: ['Book attractions in advance.','Visit landmarks early morning.','Local transport passes save up to 30%.'],
    budget: { accommodation:Math.round(b*.34), food:Math.round(b*.22), transport:Math.round(b*.13), activities:Math.round(b*.15), shopping:Math.round(b*.10), miscellaneous:Math.round(b*.06) },
    hotels: [
      { name:d+' Grand Residency', stars:3, pricePerNight:Math.round(b*.034) },
      { name:'The '+d+' Heritage Inn', stars:4, pricePerNight:Math.round(b*.054) },
      { name:d+' Budget Suites', stars:2, pricePerNight:Math.round(b*.018) }
    ]
  };
}

// ── LOADING ────────────────────────────────────────────────
function showLoading() {
  const el = document.getElementById('loading');
  if (el) el.style.display = 'flex';
  const msgs = ['Sending to Python backend…','Querying SQLite database…','Calling Claude AI…','Parsing itinerary…','Almost ready!'];
  let i = 0;
  window._lv = setInterval(() => {
    i = (i + 1) % msgs.length;
    const m = document.getElementById('loading-msg');
    if (m) m.textContent = msgs[i];
  }, 1800);
}
function hideLoading() {
  const el = document.getElementById('loading');
  if (el) el.style.display = 'none';
  clearInterval(window._lv);
}

// ── TOAST ──────────────────────────────────────────────────
function showToast(msg) {
  let t = document.getElementById('wandr-toast');
  if (!t) { t = document.createElement('div'); t.id = 'wandr-toast'; t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── INIT ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateSummary();
  fetchBudgetSplit();
});
